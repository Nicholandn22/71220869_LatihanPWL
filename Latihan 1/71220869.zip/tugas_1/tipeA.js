const addOnBird = ["Cola", "Orange Juice", "Mini Donut"];
const addOnAquarium = ["Hot Chocolate", "Ice Cream", "Snacks"];

document.getElementById("attractionType").addEventListener("change", function () {
  const addOnSelect = document.getElementById("addOn");
  const errorMessage = document.getElementById("error-message");

  addOnSelect.innerHTML = "";
  errorMessage.textContent = "";

  let PilAtraksi = this.value;
  let atraksi = [];

  if (PilAtraksi === "Bird Show") {
    atraksi = addOnBird;
  } else if (PilAtraksi === "Aquarium Visit") {
    atraksi = addOnAquarium;
  } else if (PilAtraksi === "Safari Tour") {
    errorMessage.textContent = "Mohon maaf atraksi penuh";
  }

  if (atraksi.length > 0) {
    atraksi.forEach(function (addOn) {
      let option = document.createElement("option");
      option.value = addOn;
      option.textContent = addOn;
      addOnSelect.appendChild(option);
    });
  } else if (PilAtraksi !== "Safari Tour") {
    let option = document.createElement("option");
    option.value = "";
    option.textContent = "Select";
    addOnSelect.appendChild(option);
  }
});

function makeReservation() {
  event.preventDefault();

  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const phone = document.getElementById("phone").value;
  const date = document.getElementById("tgl").value;
  const attraction = document.getElementById("attractionType").value;
  const tickets = document.getElementById("tickets").value;
  const addOn = document.getElementById("addOn").value;

  if (attraction === "Safari Tour") {
    return;
  }

  alert(
    `Reservation Details:\nName: ${name}\nEmail: ${email}\nPhone: ${phone}\nDate: ${date}\nAttraction: ${attraction}\nTickets: ${tickets}\nAdd On: ${addOn}`
  );

  document.getElementById("zooForm").reset();
}
